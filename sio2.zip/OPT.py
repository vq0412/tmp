#!/usr/bin/env python
import time
import numpy as np
from ase.io import *
from ase import Atoms, units
from ase.optimize import BFGS
from ase.calculators.siesta import Siesta
from ase.constraints import FixAtoms
# Read in the geometry from a xyz file, set the cell, boundary conditions and center
atoms = read('geom.xyz')
atoms.set_cell([
 (25,    0,    0),
 (0,    25,    0), 
 (0,     0,   25)
 ])
atoms.set_pbc((0,0,0))
# atoms.center()
# Keep some atoms fixed during the simulation
# atoms.set_constraint(FixAtoms(indices=range(0,3)))
# or atoms.set_constraint(FixAtoms(indices=(0,1,2)))
# Set the calculator and attach it to the system
calc = Siesta('1',basis='DZP',
xc='PBE',
meshcutoff=75 * units.Ry,
pulay=15,
mix=0.15,
charge=0,
kpts=[1, 1, 1])
calc.set_fdf('SaveRho', 'F')
calc.set_fdf('SaveDeltaRho', 'F')
calc.set_fdf('SaveElectrostaticPotential', 'F')
calc.set_fdf('SaveTotalPotential', 'F')
calc.set_fdf('SaveIonicCharge', 'F')
calc.set_fdf('SaveTotalCharge', 'F')
calc.set_fdf('WriteDenchar', 'F')
calc.set_fdf('COOP.Write', 'F')
calc.set_fdf('LongOutput', 'F')
calc.set_fdf('HarrisFunctional', 'F')
calc.set_fdf('DM.UseSaveDM', 'T')
calc.set_fdf('WriteHirshfeldPop', 'T')
calc.set_fdf('WriteVoronoiPop', 'T')
calc.set_fdf('SaveBaderCharge', 'T')
calc.set_fdf('WriteCoorXmol', 'T')
calc.set_fdf('ElectronicTemperature', 0.003 * units.Ry)
calc.set_fdf('OccupationFunction', 'FD')
calc.set_fdf('PAO.EnergyShift', 0.25 * units.eV)
calc.set_fdf('PAO.SplitNorm', 0.15)
calc.set_fdf('SpinPolarized', 'T')
calc.set_fdf('MaxSCFIterations', 10)
#calc.set_fdf('ProjectedDensityOfStates',
#["""-20.00 10.00 0.200 500 eV"""])
atoms.set_calculator(calc)

# Set QuasiNewton minimizer to optimize the structure
dyn = BFGS(atoms,trajectory='OPT.traj')
dyn.run(fmax=0.05,steps=1000)
